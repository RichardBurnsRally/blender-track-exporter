from typing import List, Optional

import bpy  # type: ignore

from rbr_track_formats.common import (
    compute_bounding_box_from_positions,
)
from rbr_track_formats.lbs.super_bowl import (
    SuperBowl,
    SuperBowlObject,
)

from rbr_track_addon.blender_ops import (
    prepare_objs,
    safe_remove_object,
)
from rbr_track_addon.logger import Logger

from .data_3d import (
    create_super_data3d,
    fixup_data_triangles_dtype,
    recursive_split,
)
from .textures import RBRExportTextureOracle
from ..util import create_supers_with


def export_super_bowl(
    export_texture_oracle: RBRExportTextureOracle,
    logger: Logger,
    objs: List[bpy.types.Object],
    cleanup: bool,
) -> Optional[SuperBowl]:
    try:
        dupes = prepare_objs(
            logger=logger,
            objs=objs,
            normalise=lambda _: None,
            extra_group=lambda _: None,
        )
        data_3ds = create_supers_with(
            # Specular crashes the game here
            f=lambda m, o: create_super_data3d(
                rbr_material=m,
                obj=o,
                supports_specular=False,
                supports_untextured=True,
            ),
            export_texture_oracle=export_texture_oracle,
            objs=dupes,
        )
        super_bowl_objects = []
        for data_3d in data_3ds:
            split_data_3ds = recursive_split(
                logger=logger,
                data=data_3d,
            )
            for split_data_3d in split_data_3ds:
                bounding_box = compute_bounding_box_from_positions(
                    split_data_3d.vertices["position"],
                )
                super_bowl_objects.append(
                    SuperBowlObject(
                        position=bounding_box.position,
                        data_3d=fixup_data_triangles_dtype(split_data_3d),
                    )
                )
        if len(super_bowl_objects) > 0:
            return SuperBowl(
                name="SuperBowl",
                objects=super_bowl_objects,
            )
        else:
            return None
    finally:
        if cleanup:
            try:
                for ob in dupes:
                    safe_remove_object(ob)
            except UnboundLocalError:
                pass
