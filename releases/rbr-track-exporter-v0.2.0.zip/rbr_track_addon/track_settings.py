import bpy  # type: ignore

from typing import List, Set, Tuple

from rbr_track_formats.mat import SurfaceType, SurfaceAge
from rbr_track_formats.track_settings import CloudName, TintSet, TimeOfDay, Weather, Sky

from .physical_material_editor.operator import RBR_OT_edit_material_maps
from .shaders import sky
from .shaders.sky import update_sky_value, update_sky_vector, update_sun_dir
from .shaders.texture import all_rbr_texture_nodes


class RBR_OT_add_weather_sky(bpy.types.Operator):
    bl_idname = "rbr.add_weather_sky"
    bl_label = "Add Weather"
    bl_options = {"REGISTER", "UNDO"}

    prop: bpy.props.StringProperty()  # type: ignore
    weather: bpy.props.StringProperty()  # type: ignore
    sky: bpy.props.StringProperty()  # type: ignore

    def execute(self, context: bpy.types.Context) -> Set[str]:
        x = getattr(context.scene.rbr_track_settings, self.prop).weathers.add()
        x.weather = self.weather
        x.sky = self.sky
        context.scene.rbr_track_settings.update_sky_values()
        return {"FINISHED"}


class RBR_OT_remove_weather_sky(bpy.types.Operator):
    bl_idname = "rbr.remove_weather_sky"
    bl_label = "Remove Weather"
    bl_options = {"REGISTER", "UNDO"}

    prop: bpy.props.StringProperty()  # type: ignore
    index: bpy.props.IntProperty(default=0)  # type: ignore

    def execute(self, context: bpy.types.Context) -> Set[str]:
        getattr(context.scene.rbr_track_settings, self.prop).weathers.remove(self.index)
        context.scene.rbr_track_settings.update_sky_values()
        return {"FINISHED"}


class RBRWeatherSky(bpy.types.PropertyGroup):
    weather: bpy.props.EnumProperty(  # type: ignore
        name="Weather",
        default=Weather.CRISP.name,
        items=[(w.name, w.pretty(), w.pretty(), w.id()) for w in Weather],
    )
    sky: bpy.props.EnumProperty(  # type: ignore
        name="Sky",
        default=Sky.CLEAR.name,
        items=[(s.name, s.pretty(), s.pretty(), s.id()) for s in Sky],
    )
    cloud_name: bpy.props.EnumProperty(  # type: ignore
        name="Cloud Name",
        default=CloudName.CLEAR.name,
        items=[(s.name, s.pretty(), s.pretty(), s.id()) for s in CloudName],
    )
    extinction: bpy.props.FloatProperty(  # type: ignore
        name="Extinction",  # noqa: F821
        default=0.45,
        min=0.0,
        max=1.0,
        step=1,
        update=lambda self, _: update_sky_value(sky.SKY_EXTINCTION, self.extinction),
    )
    terrain_reflectance_color: bpy.props.FloatVectorProperty(  # type: ignore
        name="Terrain Reflectance Color",
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        subtype="COLOR",  # noqa: F821
        update=lambda self, _: update_sky_vector(
            sky.SKY_TERRAIN_REFLECTANCE_COLOR, self.terrain_reflectance_color
        ),
    )
    terrain_reflectance_multiplier: bpy.props.FloatProperty(  # type: ignore
        name="Terrain Reflectance Multiplier",
        default=0.2,
        min=0.0,
        max=0.2,
        update=lambda self, _: update_sky_value(
            sky.SKY_TERRAIN_REFLECTANCE_MULTIPLIER, self.terrain_reflectance_multiplier
        ),
    )
    specular_glossiness: bpy.props.FloatProperty(  # type: ignore
        name="Specular Glossiness",
        default=4.0,
        min=1.0,
        max=14.0,
        update=lambda self, _: update_sky_value(
            sky.SKY_SPECULAR_GLOSSINESS, self.specular_glossiness
        ),
    )
    specular_alpha: bpy.props.FloatProperty(  # type: ignore
        name="Specular Alpha",
        default=0.42,
        min=0.11,
        max=1.0,
        update=lambda self, _: update_sky_value(
            sky.SKY_SPECULAR_ALPHA, self.specular_alpha
        ),
    )
    use_fog: bpy.props.BoolProperty(  # type: ignore
        name="Use Fog",
        default=False,
        update=lambda self, _: update_sky_value(sky.SKY_USE_FOG, self.use_fog),
    )
    fog_color: bpy.props.FloatVectorProperty(  # type: ignore
        name="Fog Color",
        default=(0.8, 0.8, 0.8),
        min=0.0,
        max=1.0,
        subtype="COLOR",  # noqa: F821
        update=lambda self, _: update_sky_vector(sky.SKY_FOG_COLOR, self.fog_color),
    )
    fog_start: bpy.props.FloatProperty(  # type: ignore
        name="Fog Start",
        default=0.0,
        min=-3000.0,
        max=1000.0,
        update=lambda self, _: update_sky_value(sky.SKY_FOG_START, self.fog_start),
    )
    fog_end: bpy.props.FloatProperty(  # type: ignore
        name="Fog End",
        default=1000.0,
        min=-1000.0,
        max=3000.0,
        update=lambda self, _: update_sky_value(sky.SKY_FOG_END, self.fog_end),
    )
    superbowl_fog_start: bpy.props.FloatProperty(  # type: ignore
        name="Superbowl Fog Start",
        default=0.0,
        min=-10000.0,
        max=1000.0,
        update=lambda self, _: update_sky_value(
            sky.SKY_SUPERBOWL_FOG_START, self.superbowl_fog_start
        ),
    )
    superbowl_fog_end: bpy.props.FloatProperty(  # type: ignore
        name="Superbowl Fog End",
        default=1000.0,
        min=-1000.0,
        max=10000.0,
        update=lambda self, _: update_sky_value(
            sky.SKY_SUPERBOWL_FOG_END, self.superbowl_fog_end
        ),
    )
    greenstein_value: bpy.props.FloatProperty(  # type: ignore
        name="Greenstein Value",
        default=1.0,
        min=-1.0,
        max=1.0,
        step=1,
        update=lambda self, _: update_sky_value(
            sky.SKY_GREENSTEIN_VALUE, self.greenstein_value
        ),
    )
    inscattering: bpy.props.FloatProperty(  # type: ignore
        name="Inscattering",  # noqa: F821
        default=0.33,
        min=0.0,
        max=1.0,
        step=1,
        update=lambda self, _: update_sky_value(
            sky.SKY_INSCATTERING, self.inscattering
        ),
    )
    mie_multiplier: bpy.props.FloatProperty(  # type: ignore
        name="Mie Multiplier",
        default=0.001,
        min=0.0,
        max=0.1,
        precision=6,
        step=1,
        update=lambda self, _: update_sky_value(
            sky.SKY_MIE_MULTIPLIER, self.mie_multiplier
        ),
    )
    rayleigh_multiplier: bpy.props.FloatProperty(  # type: ignore
        name="Rayleigh Multiplier",
        default=0.04096,
        min=0.0,
        max=1.0,
        precision=6,
        step=1,
        update=lambda self, _: update_sky_value(
            sky.SKY_RAYLEIGH_MULTIPLIER, self.rayleigh_multiplier
        ),
    )
    skybox_saturation: bpy.props.FloatProperty(  # type: ignore
        name="Skybox Saturation",
        default=1.0,
        min=0.0,
        max=1.0,
        step=10,
        update=lambda self, _: update_sky_value(
            sky.SKY_SKYBOX_SATURATION, self.skybox_saturation
        ),
    )
    skybox_scale: bpy.props.FloatProperty(  # type: ignore
        name="Skybox Scale",
        default=97.0,
        min=1.0,
        max=100.0,
        step=10,
        update=lambda self, _: update_sky_value(
            sky.SKY_SKYBOX_SCALE, self.skybox_scale
        ),
    )
    superbowl_scale: bpy.props.FloatProperty(  # type: ignore
        name="Superbowl Scale",
        default=0.15,
        min=0.0,
        max=2.0,
        update=lambda self, _: update_sky_value(
            sky.SKY_SUPERBOWL_SCALE, self.superbowl_scale
        ),
    )
    sun_intensity: bpy.props.FloatProperty(  # type: ignore
        name="Sun Intensity",
        default=98.0,
        min=30.0,
        max=200.0,
        step=10,
        update=lambda self, _: update_sky_value(
            sky.SKY_SUN_INTENSITY, self.sun_intensity
        ),
    )
    sun_offset: bpy.props.FloatProperty(  # type: ignore
        name="Sun Offset",
        default=-0.02,
        min=-3.0,
        max=3.0,
        step=1,
        update=lambda self, _: update_sky_value(sky.SKY_SUN_OFFSET, self.sun_offset),
    )
    turbidity: bpy.props.FloatProperty(  # type: ignore
        name="Turbidity",  # noqa: F821
        default=0.0,
        min=0.0,
        max=9.0,
        step=1,
        update=lambda self, _: update_sky_value(sky.SKY_TURBIDITY, self.turbidity),
    )

    def draw(self, layout: bpy.types.UILayout) -> None:
        layout.prop(self, "use_fog")
        if self.use_fog:
            layout.prop(self, "fog_color")
            layout.prop(self, "fog_start", slider=True)
            layout.prop(self, "fog_end", slider=True)
            layout.prop(self, "superbowl_fog_start", slider=True)
            layout.prop(self, "superbowl_fog_end", slider=True)
            layout.prop(self, "skybox_saturation", slider=True)
        layout.prop(self, "cloud_name")
        layout.prop(self, "extinction", slider=True)
        layout.prop(self, "greenstein_value", slider=True)
        layout.prop(self, "inscattering", slider=True)
        layout.prop(self, "mie_multiplier", slider=True)
        layout.prop(self, "rayleigh_multiplier", slider=True)
        layout.prop(self, "skybox_scale", slider=True)
        layout.prop(self, "specular_alpha", slider=True)
        layout.prop(self, "specular_glossiness", slider=True)
        layout.prop(self, "sun_intensity", slider=True)
        layout.prop(self, "sun_offset", slider=True)
        layout.prop(self, "superbowl_scale", slider=True)
        layout.prop(self, "terrain_reflectance_color")
        layout.prop(self, "terrain_reflectance_multiplier", slider=True)
        layout.prop(self, "turbidity", slider=True)


class RBRWeathers(bpy.types.PropertyGroup):
    weathers: bpy.props.CollectionProperty(  # type: ignore
        type=RBRWeatherSky,
    )

    def update_sky_values(self) -> None:
        print("Update sky values")
        try:
            weather = self.weathers[self.active]
            update_sky_vector(sky.SKY_FOG_COLOR, weather.fog_color)
            update_sky_value(sky.SKY_USE_FOG, weather.use_fog)
            update_sky_value(sky.SKY_GREENSTEIN_VALUE, weather.greenstein_value)
            update_sky_value(sky.SKY_INSCATTERING, weather.inscattering)
            update_sky_value(sky.SKY_MIE_MULTIPLIER, weather.mie_multiplier)
            update_sky_value(sky.SKY_RAYLEIGH_MULTIPLIER, weather.rayleigh_multiplier)
            update_sky_value(sky.SKY_SUN_INTENSITY, weather.sun_intensity)
            update_sky_value(sky.SKY_SUN_OFFSET, weather.sun_offset)
            update_sky_value(sky.SKY_SKYBOX_SATURATION, weather.skybox_saturation)
            update_sky_value(sky.SKY_SKYBOX_SCALE, weather.skybox_scale)
            update_sky_value(sky.SKY_SUPERBOWL_SCALE, weather.superbowl_scale)
            update_sky_value(sky.SKY_TURBIDITY, weather.turbidity)
            update_sky_value(sky.SKY_EXTINCTION, weather.extinction)
            update_sky_vector(
                sky.SKY_TERRAIN_REFLECTANCE_COLOR, weather.terrain_reflectance_color
            )
            update_sky_value(
                sky.SKY_TERRAIN_REFLECTANCE_MULTIPLIER,
                weather.terrain_reflectance_multiplier,
            )
            update_sky_value(sky.SKY_FOG_START, weather.fog_start)
            update_sky_value(sky.SKY_FOG_END, weather.fog_end)
            update_sky_value(sky.SKY_SUPERBOWL_FOG_START, weather.superbowl_fog_start)
            update_sky_value(sky.SKY_SUPERBOWL_FOG_END, weather.superbowl_fog_end)
            update_sky_value(sky.SKY_SPECULAR_GLOSSINESS, weather.specular_glossiness)
            update_sky_value(sky.SKY_SPECULAR_ALPHA, weather.specular_alpha)
            update_sun_dir()
        except IndexError:
            pass

    active: bpy.props.IntProperty(  # type: ignore
        update=lambda self, _: self.update_sky_values(),
    )

    add_weather: bpy.props.EnumProperty(  # type: ignore
        name="Weather",
        description="Weather",
        default=Weather.CRISP.name,
        items=[(w.name, w.pretty(), w.pretty(), w.id()) for w in Weather],
    )
    add_sky: bpy.props.EnumProperty(  # type: ignore
        name="Sky",
        description="Sky",
        default=Sky.CLEAR.name,
        items=[(s.name, s.pretty(), s.pretty(), s.id()) for s in Sky],
    )

    def draw(self, layout: bpy.types.UILayout, prop: str) -> None:
        layout.template_list(
            listtype_name="RBR_UL_weathers_list",
            list_id="",
            dataptr=self,
            propname="weathers",
            active_dataptr=self,
            active_propname="active",
            rows=1,
        )

        controls = layout.row(align=True)
        controls.prop(self, "add_weather", text="", icon="VOLUME_DATA")
        controls.prop(self, "add_sky", text="", icon="LIGHT_SUN")
        add_button = controls.operator(
            "rbr.add_weather_sky",
            icon="ADD",
            text="",
        )
        add_button.prop = prop
        add_button.weather = self.add_weather
        add_button.sky = self.add_sky
        remove_button = controls.operator(
            "rbr.remove_weather_sky",
            icon="REMOVE",
            text="",
        )
        remove_button.prop = prop
        remove_button.index = self.active

        try:
            weather = self.weathers[self.active]
            weather.draw(layout.box())
        except IndexError:
            pass


class RBRTrackSettings(bpy.types.PropertyGroup):
    def __update_surface_type__(self, context: bpy.types.Context) -> None:
        # Prevent users from disabling all surface types.
        if len(self.surface_types) < 1:
            self.surface_types = {SurfaceType.DRY.name}
        # Detect if we've disabled the currently active surface and reset it
        # This prints a warning when true, unfortunately
        if self.active_surface_type == "":
            self.active_surface_type = self.selected_surface_types()[0].name

    # This property has an invariant: at least one option must be selected.
    surface_types: bpy.props.EnumProperty(  # type: ignore
        name="Surface Types",
        description="Surface types for this track",
        items=[(t.name, t.pretty(), t.pretty(), t.bitmask()) for t in SurfaceType],
        default={SurfaceType.DRY.name},
        options={"ENUM_FLAG"},  # noqa: F821
        update=__update_surface_type__,
    )

    def selected_surface_types(self) -> List[SurfaceType]:
        """Return the possible surface types for this stage"""
        return [SurfaceType[s] for s in self.surface_types]

    # Update anything which depends on these values
    def __update_conditions__(self, context: bpy.types.Context) -> None:
        # TODO do this for each _tree_, not each _node_.
        for node in all_rbr_texture_nodes():
            node.link_context_active_texture(context)
        if RBR_OT_edit_material_maps.active_operator is not None:
            RBR_OT_edit_material_maps.active_operator.update_active_texture(context)

    def __surface_type_items__(
        self, context: bpy.types.Context
    ) -> List[Tuple[str, str, str, int]]:
        return [
            (s.name, s.pretty(), s.description(), s.value)
            # Constructed in this roundabout way to preserve natural order
            for s in SurfaceType
            if s in self.selected_surface_types()
        ]

    active_surface_type: bpy.props.EnumProperty(  # type: ignore
        name="Surface Type",
        default=SurfaceType.DRY.value,
        items=__surface_type_items__,
        update=__update_conditions__,
    )

    def get_active_surface_type(self) -> SurfaceType:
        return SurfaceType[self.active_surface_type]

    def __surface_age_items__(
        self, context: bpy.types.Context
    ) -> List[Tuple[str, str, str, int]]:
        return [(s.name, s.pretty(), s.description(), s.value) for s in SurfaceAge]

    active_surface_age: bpy.props.EnumProperty(  # type: ignore
        name="Surface Age",
        default=SurfaceAge.NEW.value,
        items=__surface_age_items__,
        update=__update_conditions__,
    )

    def update_sky_values(self) -> None:
        tint_set = self.get_tint_set()
        time_of_day = self.get_time_of_day(tint_set)
        weathers = self.get_weathers_for_tint_set(tint_set, time_of_day)
        weathers.update_sky_values()

    def get_active_surface_age(self) -> SurfaceAge:
        return SurfaceAge[self.active_surface_age]

    tint_set: bpy.props.EnumProperty(  # type: ignore
        name="Tint Set",
        description="Tint set",
        items=[(t.name, t.pretty(), t.pretty(), t.bitmask()) for t in TintSet],
        default=TintSet.MORNING.name,
        options=set(),
        update=lambda self, _: self.update_sky_values(),
    )

    def get_tint_set(self) -> TintSet:
        return TintSet[self.tint_set]

    def get_weathers_for_tint_set(
        self, tint_set: TintSet, time: TimeOfDay
    ) -> RBRWeathers:
        weathers: RBRWeathers
        if tint_set is TintSet.MORNING:
            weathers = self.morning_weathers
        elif tint_set is TintSet.NOON:
            weathers = self.noon_weathers
        elif tint_set is TintSet.EVENING:
            weathers = self.evening_weathers
        elif tint_set is TintSet.OVERCAST and time is TimeOfDay.MORNING:
            weathers = self.overcast_morning_weathers
        elif tint_set is TintSet.OVERCAST and time is TimeOfDay.NOON:
            weathers = self.overcast_noon_weathers
        elif tint_set is TintSet.OVERCAST and time is TimeOfDay.EVENING:
            weathers = self.overcast_evening_weathers
        return weathers

    overcast_time_of_day: bpy.props.EnumProperty(  # type: ignore
        name="Overcast",  # noqa: F821
        description="Overcast Time of Day",
        items=[(t.name, t.pretty(), t.pretty()) for t in TimeOfDay],
        default=TimeOfDay.MORNING.name,
        update=lambda self, _: self.update_sky_values(),
    )

    def get_time_of_day(self, tint_set: TintSet) -> TimeOfDay:
        time_of_day = tint_set.to_time_of_day()
        if time_of_day is not None:
            return time_of_day
        elif tint_set is TintSet.OVERCAST:
            return TimeOfDay[self.overcast_time_of_day]
        else:
            raise NotImplementedError(f"get_time_of_day {tint_set}")

    morning_weathers: bpy.props.PointerProperty(  # type: ignore
        type=RBRWeathers,
    )
    noon_weathers: bpy.props.PointerProperty(  # type: ignore
        type=RBRWeathers,
    )
    evening_weathers: bpy.props.PointerProperty(  # type: ignore
        type=RBRWeathers,
    )
    overcast_morning_weathers: bpy.props.PointerProperty(  # type: ignore
        type=RBRWeathers,
    )
    overcast_noon_weathers: bpy.props.PointerProperty(  # type: ignore
        type=RBRWeathers,
    )
    overcast_evening_weathers: bpy.props.PointerProperty(  # type: ignore
        type=RBRWeathers,
    )

    def draw(self, context: bpy.types.Context, layout: bpy.types.UILayout) -> None:
        layout.label(text="Weather Settings")
        layout.prop(self, "tint_set", expand=True)
        if self.tint_set == TintSet.OVERCAST.name:
            layout.prop(self, "overcast_time_of_day", text="Time")
        time = TimeOfDay[self.overcast_time_of_day]
        if self.tint_set == TintSet.MORNING.name:
            self.morning_weathers.draw(layout, "morning_weathers")
        elif self.tint_set == TintSet.NOON.name:
            self.noon_weathers.draw(layout, "noon_weathers")
        elif self.tint_set == TintSet.EVENING.name:
            self.evening_weathers.draw(layout, "evening_weathers")
        elif self.tint_set == TintSet.OVERCAST.name and time is TimeOfDay.MORNING:
            self.overcast_morning_weathers.draw(layout, "overcast_morning_weathers")
        elif self.tint_set == TintSet.OVERCAST.name and time is TimeOfDay.NOON:
            self.overcast_noon_weathers.draw(layout, "overcast_noon_weathers")
        elif self.tint_set == TintSet.OVERCAST.name and time is TimeOfDay.EVENING:
            self.overcast_evening_weathers.draw(layout, "overcast_evening_weathers")

        layout.label(text="Supported Surface Types")
        layout.prop(self, "surface_types")

        row = layout.row(align=True)
        row.label(text="Viewport")
        row.prop(self, "active_surface_type", text="")
        row.prop(self, "active_surface_age", text="")


class RBR_PT_track_settings(bpy.types.Panel):
    bl_idname = "RBR_PT_track_settings"
    bl_label = "RBR Track Settings"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "scene"

    def draw(self, context: bpy.types.Context) -> None:
        context.scene.rbr_track_settings.draw(context, self.layout)


class RBR_UL_weathers_list(bpy.types.UIList):
    def draw_item(
        self,
        context: bpy.types.Context,
        layout: bpy.types.UILayout,
        data: RBRWeathers,
        item: RBRWeatherSky,
        icon: int,
        _active_data: RBRWeathers,
        _active_propname: str,
    ) -> None:
        layout.label(text=Weather[item.weather].pretty())
        layout.label(text=Sky[item.sky].pretty())


def register() -> None:
    bpy.utils.register_class(RBRWeatherSky)
    bpy.utils.register_class(RBRWeathers)
    bpy.utils.register_class(RBRTrackSettings)
    bpy.utils.register_class(RBR_OT_add_weather_sky)
    bpy.utils.register_class(RBR_OT_remove_weather_sky)
    bpy.utils.register_class(RBR_UL_weathers_list)
    bpy.types.Scene.rbr_track_settings = bpy.props.PointerProperty(
        type=RBRTrackSettings,
    )
    bpy.utils.register_class(RBR_PT_track_settings)


def unregister() -> None:
    bpy.utils.unregister_class(RBR_PT_track_settings)
    del bpy.types.Scene.rbr_track_settings
    bpy.utils.unregister_class(RBR_UL_weathers_list)
    bpy.utils.unregister_class(RBR_OT_remove_weather_sky)
    bpy.utils.unregister_class(RBR_OT_add_weather_sky)
    bpy.utils.unregister_class(RBRTrackSettings)
    bpy.utils.unregister_class(RBRWeathers)
    bpy.utils.unregister_class(RBRWeatherSky)
