"""Fence data file.
This is a placeholder until fences are fully supported.
The game requires the fence data file to be present - without it, the game will
render the car shadow without accounting for the fog, and particles might not
work.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import List
import dataclasses
import enum

from .common import Vector3, AaBbBoundingBox


class FenceType(enum.Enum):
    FENCE_TAPE = 0x0
    FENCE_TAPE_LONG = 0x1
    FENCE_NET = 0x2
    FENCE_NET_LONG = 0x3
    FENCE_TAPE_POLE_GREY = 0x4
    FENCE_NET_POLE_GREY = 0x5
    FENCE_TAPE_POLE_BLACK = 0x6
    FENCE_NET_POLE_BLACK = 0x7
    FENCE_TAPE_POLE_BLUE = 0x8
    FENCE_NET_POLE_BLUE = 0x9
    FENCE_TAPE_POLE_RED = 0xA
    FENCE_NET_POLE_RED = 0xB
    FENCE_BARBED_WIRE = 0xC
    FENCE_BARBED_WIRE_LONG = 0xD
    FENCE_BARBED_WIRE_POLE = 0xE

    def pretty(self) -> str:
        return self.name.replace("_", " ").title()


@dataclass
class DummyObject:
    position: Vector3
    bounding_box: AaBbBoundingBox
    color: int  # TODO


@dataclass
class FenceData:
    tile_type: FenceType
    pole_type: FenceType
    tile_texture_index: int
    pole_texture_index: int
    bounding_box: AaBbBoundingBox
    dummy_objects: List[DummyObject]


@dataclass
class FNC:
    fences: List[FenceData]
    textures: List[str]
    __textures_garbage__: List[bytes] = dataclasses.field(default_factory=lambda: [])
