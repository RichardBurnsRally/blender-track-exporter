from typing import List

import bpy  # type: ignore

from rbr_track_formats import errors
from rbr_track_formats.common import Vector3
from rbr_track_formats.lbs.car_location import CarLocation

from rbr_track_addon.blender_ops import (
    apply_modifiers,
    apply_visual_transforms,
    with_duplicate_objects,
)
from rbr_track_addon.logger import Logger


def export_car_location(
    logger: Logger,
    objs: List[bpy.types.Object],
    cleanup: bool,
) -> CarLocation:
    try:
        original = objs[0]
    except IndexError:
        raise errors.E0106()
    if len(objs) > 1:
        logger.warn(
            "Found multiple car location objects, using the first ({original.name})"
        )

    def inner(dupes: List[bpy.types.Object]) -> CarLocation:
        if len(dupes) != 1:
            raise errors.RBRAddonBug("Duplicate returned != 1 car location object")
        obj = dupes[0]
        obj.name = "EXPORT Car Location"
        apply_modifiers(obj)
        # Applying visual transform in order to capture constraints.
        apply_visual_transforms([obj])
        # No purpose except to make the object look correct if cleanup is off.
        obj.constraints.clear()
        # Export
        (x, y, z) = obj.location
        obj.rotation_mode = "AXIS_ANGLE"
        (angle, axis_x, axis_y, axis_z) = obj.rotation_axis_angle
        return CarLocation(
            position=Vector3(x, z, y),
            euler_vector=Vector3(axis_x, axis_z, axis_y).scale(-angle),
        )

    car_location = with_duplicate_objects([original], inner)
    if car_location is None:
        raise errors.RBRAddonBug("Processing Car Location object failed")
    return car_location
