from typing import List

import bpy  # type: ignore

from rbr_track_formats.common import Vector3
from rbr_track_formats.dls.sound_emitters import SoundEmitter, SoundEmitters


def export_sound_emitters(objs: List[bpy.types.Object]) -> SoundEmitters:
    sound_emitters = []
    for obj in objs:
        (sx, sy, sz) = obj.scale
        max_scale = max(sx, sy, sz)
        radius = obj.empty_display_size
        sound_emitters.append(
            SoundEmitter(
                position=Vector3.from_tuple(obj.location),
                radius=radius * max_scale,
            )
        )
    return SoundEmitters(items=sound_emitters)
