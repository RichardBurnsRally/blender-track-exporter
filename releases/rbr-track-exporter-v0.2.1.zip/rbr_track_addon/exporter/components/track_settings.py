import bpy  # type: ignore
from typing import Dict, List

from rbr_track_formats.track_settings import (
    CloudName,
    serialise_track_settings,
    RGBColor,
    Sky,
    TintSet,
    TimeOfDay,
    TrackSettings,
    TrackSpecification,
    Weather,
)

from rbr_track_addon.logger import Logger
from rbr_track_addon.object_settings.types import RBRObjectSettings
from rbr_track_addon.shaders.sky import compute_left_hand_sun_dir
from rbr_track_addon.track_settings import RBRTrackSettings


def export_track_settings(
    logger: Logger,
    track_id: int,
    suns: List[bpy.types.Object],
) -> str:
    track_settings: RBRTrackSettings = bpy.context.scene.rbr_track_settings
    result: Dict[TrackSpecification, TrackSettings] = dict()
    for tint_set in TintSet:
        sun_dir = None
        for sun in suns:
            object_settings: RBRObjectSettings = sun.rbr_object_settings
            if tint_set.name in object_settings.tint_sets:
                sun_dir = compute_left_hand_sun_dir(sun)
                break

        def process_time(time_of_day: TimeOfDay) -> None:
            weathers = track_settings.get_weathers_for_tint_set(tint_set, time_of_day)
            for weather_sky in weathers.weathers:
                spec = TrackSpecification(
                    track_id=track_id,
                    tint_set=tint_set,
                    time_of_day=time_of_day,
                    weather=Weather[weather_sky.weather],
                    sky=Sky[weather_sky.sky],
                )
                result[spec] = TrackSettings(
                    sun_dir=sun_dir,
                    cloud_name=CloudName[weather_sky.cloud_name],
                    extinction=weather_sky.extinction,
                    specular_glossiness=weather_sky.specular_glossiness,
                    specular_alpha=weather_sky.specular_alpha,
                    use_fog=weather_sky.use_fog,
                    terrain_reflectance_color=RGBColor.from_list(
                        weather_sky.terrain_reflectance_color
                    ),
                    terrain_reflectance=weather_sky.terrain_reflectance_multiplier,
                    fog_color=RGBColor.from_list(weather_sky.fog_color),
                    fog_start=weather_sky.fog_start,
                    fog_end=weather_sky.fog_end,
                    superbowl_fog_start=weather_sky.superbowl_fog_start,
                    superbowl_fog_end=weather_sky.superbowl_fog_end,
                    greenstein_value=weather_sky.greenstein_value,
                    inscattering=weather_sky.inscattering,
                    mie_multiplier=weather_sky.mie_multiplier,
                    rayleigh_multiplier=weather_sky.rayleigh_multiplier,
                    skybox_saturation=weather_sky.skybox_saturation,
                    skybox_scale=weather_sky.skybox_scale,
                    superbowl_scale=weather_sky.superbowl_scale,
                    sun_intensity=weather_sky.sun_intensity,
                    sun_offset=weather_sky.sun_offset,
                    turbidity=weather_sky.turbidity,
                )

        if tint_set is TintSet.OVERCAST:
            # We need to export all of the times for overcast at once.
            for time_of_day in TimeOfDay:
                process_time(time_of_day)
        else:
            time_of_day = track_settings.get_time_of_day(tint_set)
            process_time(time_of_day)

    if len(result) == 0:
        logger.warn(
            "Exporting empty track settings file because there are no weathers"
            + " specified (see 'RBR Track Settings' in the scene properties)"
        )
    return serialise_track_settings(result)
