from typing import List, Optional

import bpy  # type: ignore

from rbr_track_formats.lbs.water_objects import (
    WaterObject,
    WaterObjects,
)

from rbr_track_addon.blender_ops import (
    with_duplicate_objects,
    apply_transforms,
    make_data_single_user,
    apply_modifiers,
    make_instances_real,
    separate_by_material,
)
from rbr_track_addon.logger import Logger
from rbr_track_addon.object_settings.types import RBRObjectSettings, RBRObjectType

from .data_3d import (
    create_super_data3d,
    fixup_data_triangles_dtype,
    recursive_split,
)
from .textures import RBRExportTextureOracle
from ..util import create_supers_with


def export_water_objects(
    export_texture_oracle: RBRExportTextureOracle,
    logger: Logger,
    input_objs: List[bpy.types.Object],
    cleanup: bool,
) -> Optional[WaterObjects]:
    def inner(dupes: List[bpy.types.Object]) -> Optional[WaterObjects]:
        logger.info("Applying modifiers")
        real_dupes = []
        for obj in dupes:
            ros: RBRObjectSettings = obj.rbr_object_settings
            ros.type = RBRObjectType.NONE.name
            make_data_single_user(obj)
            apply_modifiers(obj)
            real_dupes.extend(make_instances_real(logger, obj))
        apply_transforms(real_dupes)

        logger.info("Creating water objects")
        water_objects = []
        for obj in real_dupes:
            separated = separate_by_material([obj])

            data_3ds = create_supers_with(
                f=lambda m, o: create_super_data3d(
                    rbr_material=m,
                    obj=o,
                    supports_specular=True,
                    supports_untextured=False,
                ),
                export_texture_oracle=export_texture_oracle,
                objs=separated,
            )

            fixed_data_3ds = []
            for data_3d in data_3ds:
                split_data_3ds = recursive_split(
                    logger=logger,
                    data=data_3d,
                )
                for split_data_3d in split_data_3ds:
                    fixed_data_3ds.append(fixup_data_triangles_dtype(split_data_3d))

            water_objects.append(
                WaterObject(
                    name=obj.name,
                    data_3d=fixed_data_3ds,
                )
            )

        if len(water_objects) > 0:
            return WaterObjects(objects=water_objects)
        else:
            return None

    logger.info("Duplicating objects")
    return with_duplicate_objects(
        objs=input_objs,
        f=inner,
        cleanup=cleanup,
    )
