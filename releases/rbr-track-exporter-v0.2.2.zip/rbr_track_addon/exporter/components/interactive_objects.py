from __future__ import annotations
from typing import Dict, List, Tuple

import bpy  # type: ignore

from rbr_track_formats.common import (
    Key,
    Vector3,
    Matrix3x3,
    Matrix4x4,
)
from rbr_track_formats.lbs.common import ObjectData3D
from rbr_track_formats.lbs.interactive_objects import (
    InteractiveObject,
    InteractiveObjects,
    Instance,
)
from rbr_track_formats.trk.shape_collision_meshes import (
    ObjectKind,
    Quaternion,
)

from rbr_track_addon.blender_ops import (
    apply_modifiers,
    apply_transforms,
    make_data_single_user,
    make_instances_real,
    safe_remove_object,
    separate_by_material,
)
from rbr_track_addon.logger import Logger
from rbr_track_addon.object_settings.types import RBRObjectSettings, RBRObjectType

from .textures import RBRExportTextureOracle
from .data_3d import (
    create_super_data3d,
    fixup_data_triangles_dtype,
    recursive_split,
)
from ..util import (
    create_supers_with,
    KeyGen,
)


def make_data_3ds(
    export_texture_oracle: RBRExportTextureOracle,
    logger: Logger,
    mesh: bpy.types.Mesh,
    cleanup: bool,
) -> List[ObjectData3D]:
    logger.info("Duplicating object")
    # Must copy the mesh so separate doesn't mess with the original mesh
    obj = bpy.data.objects.new(mesh.name, mesh.copy())
    try:
        bpy.context.scene.collection.objects.link(obj)

        logger.info("Applying modifiers")
        ros: RBRObjectSettings = obj.rbr_object_settings
        ros.type = RBRObjectType.NONE.name
        make_data_single_user(obj)
        apply_modifiers(obj)
        real_objs = make_instances_real(logger, obj)
        apply_transforms(real_objs)

        logger.info("Creating interactive object data")
        result_data_3ds = []
        for obj in real_objs:
            separated = separate_by_material([obj])

            data_3ds = create_supers_with(
                f=lambda m, o: create_super_data3d(
                    rbr_material=m,
                    obj=o,
                    supports_specular=False,
                    # The game can load untextured objects, but the object is at the world origin.
                    supports_untextured=False,
                ),
                export_texture_oracle=export_texture_oracle,
                objs=separated,
            )

            for data_3d in data_3ds:
                split_data_3ds = recursive_split(
                    logger=logger,
                    data=data_3d,
                )
                for split_data_3d in split_data_3ds:
                    result_data_3ds.append(fixup_data_triangles_dtype(split_data_3d))

        return result_data_3ds
    finally:
        if cleanup:
            safe_remove_object(obj)
            try:
                for obj in separated:
                    safe_remove_object(obj)
            except UnboundLocalError:
                pass


def make_interactive_object(
    export_texture_oracle: RBRExportTextureOracle,
    logger: Logger,
    keygen: KeyGen,
    mesh_name: str,
    objs: List[bpy.types.Object],
    cleanup: bool,
) -> Tuple[Dict[str, Key], List[InteractiveObject]]:
    """Given a mesh marked as a shape collision mesh and all of the objects
    which use it, create the exportable format. This returns a list because
    mesh materials are stored in the objects, so one mesh may lead to multiple
    shape collision meshes.
    """
    mesh = bpy.data.meshes[mesh_name]
    data_3ds = make_data_3ds(
        export_texture_oracle=export_texture_oracle,
        logger=logger,
        mesh=mesh,
        cleanup=cleanup,
    )
    try:
        instances_by_kind: Dict[ObjectKind, List[Instance]] = dict()
        interactive_object_keys: Dict[str, Key] = dict()
        for obj in objs:
            object_settings: RBRObjectSettings = obj.rbr_object_settings
            kind = ObjectKind[object_settings.interactive_object_kind]

            # TODO scale does not work in game, when you touch the object it
            # shrinks to unit scale.
            scale_matrix = Matrix3x3(
                Vector3(obj.scale.x, 0, 0),
                Vector3(0, obj.scale.z, 0),
                Vector3(0, 0, obj.scale.y),
            )
            original_mode = obj.rotation_mode
            obj.rotation_mode = "QUATERNION"
            rot_quaternion = Quaternion(
                w=obj.rotation_quaternion.w,
                x=obj.rotation_quaternion.x,
                y=obj.rotation_quaternion.y,
                z=obj.rotation_quaternion.z,
            )
            obj.rotation_mode = original_mode
            rot_matrix = rot_quaternion.flip_handedness().to_3x3_matrix()

            key = keygen.new_key()
            interactive_object_keys[obj.name] = key

            instance = Instance(
                key=key,
                transformation_matrix=Matrix4x4.from_position_and_rotation_matrix(
                    position=Vector3.from_tuple(
                        obj.location.to_tuple()
                    ).flip_handedness(),
                    rotation=rot_matrix.mul(scale_matrix),
                ),
            )
            if kind in instances_by_kind:
                instances_by_kind[kind].append(instance)
            else:
                instances_by_kind[kind] = [instance]
        interactive_objects = []
        for object_kind, instances in instances_by_kind.items():
            interactive_objects.append(
                InteractiveObject(
                    name=mesh_name,
                    object_kind=object_kind,
                    data_3d=data_3ds,
                    instances=instances,
                )
            )
        return (interactive_object_keys, interactive_objects)
    finally:
        if cleanup:
            pass


def export_interactive_objects(
    export_texture_oracle: RBRExportTextureOracle,
    logger: Logger,
    keygen: KeyGen,
    objs: List[bpy.types.Object],
    cleanup: bool,
) -> Tuple[Dict[str, Key], InteractiveObjects]:
    blender_meshes: Dict[str, bpy.types.Object] = dict()
    for obj in objs:
        blender_mesh = obj.data
        if blender_mesh.name in blender_meshes:
            blender_meshes[blender_mesh.name].append(obj)
        else:
            blender_meshes[blender_mesh.name] = [obj]
    all_interactive_object_keys: Dict[str, Key] = dict()
    objects = []
    for mesh_name, objs in blender_meshes.items():
        (interactive_object_keys, interactive_objects) = make_interactive_object(
            export_texture_oracle=export_texture_oracle,
            logger=logger,
            keygen=keygen,
            mesh_name=mesh_name,
            objs=objs,
            cleanup=cleanup,
        )
        all_interactive_object_keys.update(interactive_object_keys)
        objects.extend(interactive_objects)
    return (all_interactive_object_keys, InteractiveObjects(objects=objects))
