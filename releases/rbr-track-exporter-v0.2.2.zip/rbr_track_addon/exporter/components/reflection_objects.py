from typing import List, Optional

import bpy  # type: ignore

from rbr_track_formats.lbs.reflection_objects import (
    ReflectionObject,
    ReflectionObjects,
)

from rbr_track_addon.blender_ops import (
    apply_modifiers,
    apply_transforms,
    make_data_single_user,
    make_instances_real,
    separate_by_material,
    with_duplicate_objects,
)
from rbr_track_addon.object_settings.types import RBRObjectSettings, RBRObjectType
from rbr_track_addon.logger import Logger

from .data_3d import (
    create_super_data3d,
    fixup_data_triangles_dtype,
    recursive_split,
)
from .textures import RBRExportTextureOracle
from ..util import create_supers_with


def export_reflection_objects(
    export_texture_oracle: RBRExportTextureOracle,
    logger: Logger,
    objs: List[bpy.types.Object],
    cleanup: bool,
) -> Optional[ReflectionObjects]:
    def inner(dupes: List[bpy.types.Object]) -> Optional[ReflectionObjects]:
        logger.info("Applying modifiers")
        real_dupes = []
        for obj in dupes:
            ros: RBRObjectSettings = obj.rbr_object_settings
            ros.type = RBRObjectType.NONE.name
            make_data_single_user(obj)
            apply_modifiers(obj)
            real_dupes.extend(make_instances_real(logger, obj))
        apply_transforms(real_dupes)

        logger.info("Creating reflection objects")
        reflection_objects = []
        for obj in real_dupes:
            separated = separate_by_material([obj])

            data_3ds = create_supers_with(
                f=lambda m, o: create_super_data3d(
                    rbr_material=m,
                    obj=o,
                    supports_specular=False,
                    supports_untextured=False,
                ),
                export_texture_oracle=export_texture_oracle,
                objs=separated,
            )

            fixed_data_3ds = []
            for data_3d in data_3ds:
                split_data_3ds = recursive_split(
                    logger=logger,
                    data=data_3d,
                )
                for split_data_3d in split_data_3ds:
                    fixed_data_3ds.append(fixup_data_triangles_dtype(split_data_3d))

            reflection_objects.append(
                ReflectionObject(
                    name=obj.name,
                    data_3d=fixed_data_3ds,
                )
            )

        if len(reflection_objects) > 0:
            return ReflectionObjects(objects=reflection_objects)
        else:
            return None

    logger.info("Duplicating objects")
    return with_duplicate_objects(
        objs=objs,
        f=inner,
        cleanup=cleanup,
    )
