from typing import List, Optional

import bpy  # type: ignore

from rbr_track_formats.common import Vector3
from rbr_track_formats.dls.registration_zone import RegistrationZone


def export_registration_zone(
    objs: List[bpy.types.Object],
) -> Optional[RegistrationZone]:
    if len(objs) == 0:
        return None
    zone_obj = objs[0]
    (sx, sy, sz) = zone_obj.scale
    max_scale = max(sx, sy, sz)
    radius = zone_obj.empty_display_size
    return RegistrationZone(
        position=Vector3.from_tuple(zone_obj.location),
        radius=radius * max_scale,
    )
