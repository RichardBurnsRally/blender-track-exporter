from __future__ import annotations
from typing import Dict, List, Optional, Union

import bpy  # type: ignore

from rbr_track_formats import errors
from rbr_track_formats.common import Key, Vector3, AaBbBoundingBox
from rbr_track_formats.mat import MaterialID
from rbr_track_formats.trk.shape_collision_meshes import (
    BoundingSphere,
    DynamicMesh,
    FaceData,
    ObjectData,
    ObjectKind,
    Quaternion,
    ShapeCollisionMesh,
    ShapeCollisionMeshes,
    StaticMesh,
)

from rbr_track_addon.logger import Logger
from rbr_track_addon.object_settings.types import RBRObjectSettings

from ..util import KeyGen


def make_shape_collision_mesh(
    keygen: KeyGen,
    mesh_name: str,
    interactive_object_keys: Dict[str, Key],
    objs: List[bpy.types.Object],
    cleanup: bool,
) -> List[ShapeCollisionMesh]:
    """Given a mesh marked as a shape collision mesh and all of the objects
    which use it, create the exportable format. This returns a list because
    mesh materials are stored in the objects, so one mesh may lead to multiple
    shape collision meshes.
    """
    mesh = bpy.data.meshes[mesh_name]
    mesh.calc_loop_triangles()
    vertices = [Vector3.from_tuple(v.co.to_tuple()) for v in mesh.vertices]
    faces = []
    for loop_triangle in mesh.loop_triangles:
        faces.append(
            FaceData(
                index_a=loop_triangle.vertices[0],
                index_b=loop_triangle.vertices[1],
                index_c=loop_triangle.vertices[2],
            )
        )
    try:
        objects_by_material: Dict[
            Union[MaterialID, ObjectKind], List[ObjectData]
        ] = dict()
        for obj in objs:

            # Try to find the soft volume
            soft_volume: Optional[Union[BoundingSphere, AaBbBoundingBox]] = None
            for child in obj.children:
                if child.data is not None:
                    continue
                if child.empty_display_type == "SPHERE":
                    s_max = max(child.scale.x, child.scale.y, child.scale.z)
                    soft_volume = BoundingSphere(
                        position=Vector3.from_tuple(child.location.to_tuple()),
                        radius=s_max * child.empty_display_size,
                    )
                    break
                elif child.empty_display_type == "CUBE":
                    soft_volume = AaBbBoundingBox(
                        position=Vector3.from_tuple(child.location.to_tuple()),
                        size=Vector3.from_tuple(child.scale.to_tuple())
                        .scale(child.empty_display_size)
                        .flip_handedness(),
                    )
                    break

            # Determine if we are an interactive object by checking the
            # dictionary for the parent. The parent was not duplicated here, so
            # we know the name is the same as the ones in the dict.
            # Pop the item so that we can check we've matched all of the
            # interactive objects at the end.
            parent = None
            is_static = True
            key = None
            if obj.parent is not None:
                parent = obj.parent
                key = interactive_object_keys.pop(obj.parent.name, None)
            if key is not None:
                is_static = False
            else:
                key = keygen.new_key()
            # Get the world position
            (position, quaternion, scale) = obj.matrix_world.decompose()
            object_data = ObjectData(
                key=key,
                position=Vector3.from_tuple(position.to_tuple()),
                rotation=Quaternion(
                    x=quaternion.x,
                    y=quaternion.y,
                    z=quaternion.z,
                    w=quaternion.w,
                ),
                scale=Vector3.from_tuple(scale.to_tuple()),
            )
            if is_static:
                object_settings: RBRObjectSettings = obj.rbr_object_settings
                mat = MaterialID[object_settings.shape_collision_mesh_material]
                if mat in objects_by_material:
                    objects_by_material[mat].append(object_data)
                else:
                    objects_by_material[mat] = [object_data]
            else:
                if parent is None:
                    raise errors.RBRAddonBug("Missing parent for dynamic object")
                parent_settings: RBRObjectSettings = parent.rbr_object_settings
                object_kind = ObjectKind[parent_settings.interactive_object_kind]
                if object_kind in objects_by_material:
                    objects_by_material[object_kind].append(object_data)
                else:
                    objects_by_material[object_kind] = [object_data]
        shape_colmeshes = []
        for material_kind, objects in objects_by_material.items():
            mesh_type: Union[DynamicMesh, StaticMesh]
            if isinstance(material_kind, ObjectKind):
                mesh_type = DynamicMesh(
                    kind=material_kind,
                )
            else:
                mesh_type = StaticMesh(
                    material=material_kind,
                    soft_volume=soft_volume,
                )
            shape_colmeshes.append(
                ShapeCollisionMesh(
                    name=mesh_name,
                    mesh_type=mesh_type,
                    vertices=vertices,
                    faces=faces,
                    objects=objects,
                )
            )
        return shape_colmeshes
    finally:
        if cleanup:
            pass


def export_shape_collision_meshes(
    keygen: KeyGen,
    logger: Logger,
    interactive_object_keys: Dict[str, Key],
    objs: List[bpy.types.Object],
    cleanup: bool,
) -> ShapeCollisionMeshes:
    blender_meshes: Dict[str, bpy.types.Object] = dict()
    logger.info(
        f"Interactive object count: {len(interactive_object_keys)}, shape colmesh count: {len(objs)}"
    )
    for obj in objs:
        blender_mesh = obj.data
        if blender_mesh.name in blender_meshes:
            blender_meshes[blender_mesh.name].append(obj)
        else:
            blender_meshes[blender_mesh.name] = [obj]
    shape_meshes = []
    for mesh_name, objs in blender_meshes.items():
        logger.info(f"Handling mesh {mesh_name}, object count: {len(objs)}")
        shape_meshes.extend(
            make_shape_collision_mesh(
                keygen=keygen,
                mesh_name=mesh_name,
                interactive_object_keys=interactive_object_keys,
                objs=objs,
                cleanup=cleanup,
            )
        )
    if len(interactive_object_keys) != 0:
        raise errors.E0130(
            interactive_objects=set(interactive_object_keys.keys()),
        )
    return ShapeCollisionMeshes(
        meshes=shape_meshes,
    )
