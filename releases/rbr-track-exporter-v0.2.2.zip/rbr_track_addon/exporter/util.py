from dataclasses import dataclass
from typing import Callable, List, TypeVar

import bpy  # type: ignore

from rbr_track_formats import errors
from rbr_track_formats.common import Key

from .components.textures import RBRResolvedMaterial, RBRExportTextureOracle


@dataclass
class KeyGen:
    last_key: int = 1

    def new_key(self) -> Key:
        self.last_key += 1
        return Key(id=self.last_key)


A = TypeVar("A")


def create_supers_with(
    f: Callable[[RBRResolvedMaterial, bpy.types.Object], A],
    export_texture_oracle: RBRExportTextureOracle,
    objs: List[bpy.types.Object],
) -> List[A]:
    result = []
    for obj in objs:
        material_name = obj.data.materials[0].name
        rbr_material = export_texture_oracle.resolve_material(material_name)
        if rbr_material is None:
            raise errors.E0104(
                object_name=obj.name,
                material_name=material_name,
            )
        result.append(f(rbr_material, obj))
    return result
