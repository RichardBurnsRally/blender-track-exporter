import numpy as np

from rbr_track_formats import dtypes, errors
from rbr_track_formats.common import (
    compute_bounding_box_from_positions,
    NumpyArray,
)
from rbr_track_formats.lbs.common import RenderStateFlags
from rbr_track_formats.lbs.object_blocks import (
    ObjectBlock,
    ObjectBlockLOD,
)

from rbr_track_addon.blender_ops import TracedObject
from rbr_track_addon.object_settings.types import (
    ObjectBlocksDetail,
    ObjectBlocksLODMode,
    RBRObjectSettings,
)
from rbr_track_addon.util import (
    get_uv_array,
    mesh_loop_triangles,
    mesh_vertices_to_loop_positions,
)

from .textures import RBRResolvedMaterial
from .. import vcol_bake


def create_super_object_block(
    rbr_material: RBRResolvedMaterial,
    traced_obj: TracedObject,
) -> ObjectBlock:
    """Create an object block which does not conform to chunk boundaries"""

    # TODO I'm not sure this is correct, but users probably shouldn't be trying
    # to export opaque objects as object blocks, so it'll do for now.
    if not rbr_material.transparent:
        raise errors.E0128(
            object_name=traced_obj.source_name(),
            material_name=rbr_material.name,
        )

    rbr_object_settings: RBRObjectSettings = traced_obj.obj.rbr_object_settings

    mesh = traced_obj.obj.data
    mesh.calc_loop_triangles()

    # Others are not supported.
    vertices = np.zeros(len(mesh.loops), dtype=dtypes.single_texture_sway)

    (_, position) = mesh_vertices_to_loop_positions(mesh, dtype=dtypes.vector3_lh)
    bounding_box = compute_bounding_box_from_positions(position)
    vertices["position"] = position
    vertices["color"] = vcol_bake.bake(mesh)

    if not rbr_material.render_type.has_diffuse_1():
        raise errors.E0129(
            object_name=traced_obj.source_name(),
            material_name=rbr_material.name,
        )
    if rbr_material.render_type.has_diffuse_2():
        raise errors.E0129(
            object_name=traced_obj.source_name(),
            material_name=rbr_material.name,
        )
    diffuse_1_uv = get_uv_array(
        mesh=mesh,
        layer=rbr_material.diffuse_1_uv,
        invert_v=True,
        material_name=rbr_material.name,
    )
    if diffuse_1_uv is None:
        raise errors.RBRAddonBug("Missing diffuse_1_uv in create_super_object_block")
    vertices["diffuse_1_uv"] = diffuse_1_uv

    vertices["sway"] = vcol_bake.bake_sway(mesh)

    # Define the level of detail settings and the buffers
    all_triangles = mesh_loop_triangles(mesh)
    lod_mode = ObjectBlocksLODMode[rbr_object_settings.object_blocks_lod_mode]
    if lod_mode is ObjectBlocksLODMode.OBJECT:
        detail = ObjectBlocksDetail[rbr_object_settings.object_blocks_detail]
        if detail is ObjectBlocksDetail.NEAR:
            lod = ObjectBlockLOD.NEAR_GEOMETRY_FROM_MAIN_BUFFER
            main_buffer = all_triangles
            far_buffer = None
        elif detail is ObjectBlocksDetail.FAR:
            lod = ObjectBlockLOD.FAR_GEOMETRY_FROM_MAIN_BUFFER
            main_buffer = all_triangles
            far_buffer = None
        elif detail is ObjectBlocksDetail.BOTH:
            lod = ObjectBlockLOD.FAR_GEOMETRY_FROM_FAR_BUFFER
            main_buffer = all_triangles
            far_buffer = all_triangles
        else:
            raise errors.RBRAddonBug(f"Unhandled case for detail: {detail.name}")
    elif lod_mode is ObjectBlocksLODMode.FACE_MAP:
        # The python access to face maps (outside of bmesh) is pretty buggy.
        # The face map layers are stored in the object data (obj.face_maps), and the
        # per polygon data is accessible under the mesh (mesh.face_maps).
        # However, the mesh face map data only ever has one layer with name "",
        # which is also labeled the active layer. But there's another bug: the
        # active layer is not the selected one in the UI, it's actually the one with
        # the zero index. So in order to extract face map information we need to
        # step through the face maps in obj.face_maps, deleting them as we go,
        # extracting mesh.face_maps.active.data[..] for each one.
        face_maps = dict()
        for face_map in traced_obj.obj.face_maps:
            if face_map.index != 0:
                raise errors.RBRAddonBug("Expected 0-indexed face map")
            # The value is -1 if the face is not in the map, else 0.
            arr = np.zeros(len(mesh.polygons), dtype=bool)
            mesh.face_maps.active.data.foreach_get("value", arr)
            face_maps[face_map.name] = np.logical_not(arr)
            traced_obj.obj.face_maps.remove(face_map)

        def get_triangles_for_map(face_map: NumpyArray) -> NumpyArray:
            # input face map is indexed by polygon
            triangle_to_polygon = np.zeros(len(mesh.loop_triangles), dtype=int)
            mesh.loop_triangles.foreach_get("polygon_index", triangle_to_polygon)
            triangle_to_face_map = np.take(face_map, triangle_to_polygon)
            return all_triangles[triangle_to_face_map]

        # Triangles can only be in a single face map, so we just assume that all
        # geometry is near. Not ideal, but matches the original stages where
        # far geometry is a subset of near.
        main_buffer = all_triangles

        far_map = face_maps.get(rbr_object_settings.object_blocks_far_face_map)
        lod = ObjectBlockLOD.FAR_GEOMETRY_FROM_FAR_BUFFER
        if far_map is None:
            far_buffer = all_triangles
        else:
            far_buffer = get_triangles_for_map(far_map)
    else:
        raise errors.RBRAddonBug(f"Unhandled case for lod mode: {lod_mode.name}")

    render_state_flags = RenderStateFlags(0)
    if not rbr_material.use_backface_culling:
        render_state_flags |= RenderStateFlags.NO_CULLING

    return ObjectBlock(
        render_state_flags=render_state_flags,
        diffuse_texture_index_1=rbr_material.diffuse_1,
        diffuse_texture_index_2=None,  # Game crashes when loading.
        main_buffer=main_buffer,
        lod=lod,
        far_buffer=far_buffer,
        vertices=vertices,
        bounding_box=bounding_box,
    )
