from typing import Dict

import bpy  # type: ignore
from nodeitems_utils import NodeItem, register_node_categories, unregister_node_categories  # type: ignore
from nodeitems_builtins import ShaderNodeCategory  # type: ignore

from . import operator
from . import properties
from . import uv_velocity
from . import shader_node
from . import sky
from . import texture
from . import time
from . import utils  # noqa: F401


rbr_shader_category_list = [
    ShaderNodeCategory(
        "RBR_SHADER_CATEGORY",
        "RBR Nodes",
        items=[
            NodeItem(shader_node.ShaderNodeRBR.bl_name),
            NodeItem(texture.ShaderNodeRBRTexture.bl_name),
            NodeItem(uv_velocity.ShaderNodeUVVelocity.bl_name),
            NodeItem(sky.ShaderNodeRBRSky.bl_name),
        ],
    )
]


def register() -> None:
    properties.register()
    time.register()
    uv_velocity.register()
    texture.register()
    shader_node.register()
    sky.register()
    operator.register()
    register_node_categories("RBR_SHADER_NODES", rbr_shader_category_list)


def unregister() -> None:
    unregister_node_categories("RBR_SHADER_NODES")
    operator.unregister()
    sky.unregister()
    shader_node.unregister()
    texture.unregister()
    uv_velocity.unregister()
    time.unregister()
    properties.unregister()


def set_colorspace(node_tree: bpy.types.NodeTree) -> None:
    for node in node_tree.nodes:
        if isinstance(node, bpy.types.ShaderNodeTexImage):
            if node.image is not None:
                node.image.colorspace_settings.name = "sRGB"


def migrate_split_shaders() -> None:
    texture_trees = dict()
    for rbr_texture in bpy.context.scene.rbr_textures.textures:
        node_tree = texture.setup_texture_node_tree()
        node_tree.name = texture.RBR_TEXTURE_NODE_TREE_PREFIX + rbr_texture.name
        internal = node_tree.nodes["internal"]
        internal.is_road_surface = rbr_texture.is_road_surface
        for original in rbr_texture.material_maps:
            new = internal.material_maps.add()
            new.copy(original)
        node_tree.nodes["dry/new"].image = rbr_texture.dry_new
        node_tree.nodes["dry/normal"].image = rbr_texture.dry_normal
        node_tree.nodes["dry/worn"].image = rbr_texture.dry_worn
        node_tree.nodes["damp/new"].image = rbr_texture.damp_new
        node_tree.nodes["damp/normal"].image = rbr_texture.damp_normal
        node_tree.nodes["damp/worn"].image = rbr_texture.damp_worn
        node_tree.nodes["wet/new"].image = rbr_texture.wet_new
        node_tree.nodes["wet/normal"].image = rbr_texture.wet_normal
        node_tree.nodes["wet/worn"].image = rbr_texture.wet_worn
        set_colorspace(node_tree)
        texture_trees[rbr_texture.name] = node_tree
    specular_texture_trees = dict()
    for rbr_texture in bpy.context.scene.rbr_textures.specular_textures:
        node_tree = texture.setup_texture_node_tree()
        node_tree.name = texture.RBR_TEXTURE_NODE_TREE_PREFIX + rbr_texture.name
        internal = node_tree.nodes["internal"]
        node_tree.nodes["dry/new"].image = rbr_texture.dry
        node_tree.nodes["damp/new"].image = rbr_texture.damp
        node_tree.nodes["wet/new"].image = rbr_texture.wet
        set_colorspace(node_tree)
        specular_texture_trees[rbr_texture.name] = node_tree
    for material in bpy.data.materials:
        if material.use_nodes:
            migrate_node_tree(
                node_tree=material.node_tree,
                texture_trees=texture_trees,
                specular_texture_trees=specular_texture_trees,
            )


def migrate_node_tree(
    node_tree: bpy.types.NodeTree,
    texture_trees: Dict[str, bpy.types.NodeTree],
    specular_texture_trees: Dict[str, bpy.types.NodeTree],
) -> None:

    for node in node_tree.nodes:
        if isinstance(node, shader_node.ShaderNodeRBR):
            diffuse_1 = texture_trees.get(node.diffuse_1)
            if diffuse_1 is None:
                node.has_diffuse_1 = False
            else:
                node.has_diffuse_1 = True
                shader_node.create_texture_and_uv(
                    node_tree=node_tree,
                    tex_tree=diffuse_1,
                    uv_layer=node.diffuse_1_uv,
                    color=node.inputs["Diffuse Texture 1"],
                    alpha=node.inputs["Diffuse Texture 1 Alpha"],
                    uv_velocity=node.diffuse_1_velocity,
                )
                diffuse_2 = texture_trees.get(node.diffuse_2)
                if diffuse_2 is not None:
                    node.has_diffuse_2 = True
                    shader_node.create_texture_and_uv(
                        node_tree=node_tree,
                        tex_tree=diffuse_2,
                        uv_layer=node.diffuse_2_uv,
                        color=node.inputs["Diffuse Texture 2"],
                        alpha=node.inputs["Diffuse Texture 2 Alpha"],
                        uv_velocity=node.diffuse_2_velocity,
                    )
                specular = specular_texture_trees.get(node.specular)
                if specular is not None:
                    node.has_specular = True
                    shader_node.create_texture_and_uv(
                        node_tree=node_tree,
                        tex_tree=specular,
                        uv_layer=node.specular_uv,
                        color=node.inputs["Specular Texture"],
                        alpha=node.inputs["Specular Texture Alpha"],
                        uv_velocity=node.specular_velocity,
                    )
